document.body.addEventListener('click', function() {
    var audio = document.getElementById('audio');
    audio.play();
});